let navbar = document.querySelector('.navbar');
let searchForm = document.querySelector('.search-form');
let cartItemContainer = document.querySelector('.cart-items-container'); 
let cartItemsDiv = document.querySelector('#cart-items'); 
let cartItems = []; 


document.querySelector('#search-btn').onclick = () => {
    searchForm.classList.toggle('active');
    navbar.classList.remove('active');
    cartItemContainer.classList.remove('active');
};

document.querySelector('#cart-btn').onclick = () => {
    cartItemContainer.classList.toggle('active'); 
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    updateCartUI(); 
};

document.addEventListener('DOMContentLoaded', () => {
    let navbar = document.querySelector('.navbar');
    let searchForm = document.querySelector('.search-form');
    let cartItemContainer = document.querySelector('.cart-items-container');

    window.onscroll = () => {
        if (navbar) navbar.classList.remove('active');
        if (searchForm) searchForm.classList.remove('active');
        if (cartItemContainer) cartItemContainer.classList.remove('active');
    };
});


function addToCart(event) {
    let button = event.target;
    let item = button.closest('.box');
    let itemName = item.querySelector('h3').innerText;
    let itemPrice = item.querySelector('.price').childNodes[0].nodeValue.trim();
    let itemImage = item.querySelector('img').src;

    let existingItem = cartItems.find(cartItem => cartItem.name === itemName);
    if (!existingItem) {
        let cartItem = {
            name: itemName,
            price: itemPrice,
            image: itemImage
        };
        cartItems.push(cartItem);
        
        localStorage.setItem("cartItems", JSON.stringify(cartItems));

        updateCartUI();

        cartItemContainer.classList.add('active');
    } else {
        alert('Item is already in the cart');
    }
}

function updateCartUI() {
    let cartContainer = document.querySelector('#cart-items');
    cartContainer.innerHTML = ''; 

    if (cartItems.length === 0) {
        cartContainer.innerHTML = `<p class="cart-empty" style="text-align:center; font-size:1.6rem;">Cart is empty</p>`;
        document.querySelector('#checkout-btn').style.display = 'none'; 
    } else {
        document.querySelector('.cart-empty')?.remove(); 

        cartItems.forEach((item, index) => {
            let cartItemHTML = `
                <div class="cart-item">
                    <span class="fas fa-times" onclick="removeFromCart(${index})"></span>
                    <img src="${item.image}" alt="${item.name}">
                    <div class="content">
                        <h3>${item.name}</h3>
                        <div class="price">${item.price}</div>
                    </div>
                </div>
            `;
            cartContainer.innerHTML += cartItemHTML;
        });

        document.querySelector('#checkout-btn').style.display = 'block';
    }
}

function removeFromCart(index) {
    cartItems.splice(index, 1); 

    localStorage.setItem("cartItems", JSON.stringify(cartItems));

    updateCartUI(); 
}

function loadCartItems() {
    let storedCart = localStorage.getItem("cartItems");
    if (storedCart) {
        cartItems = JSON.parse(storedCart);
        updateCartUI();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.menu .box .btn').forEach(button => {
        button.addEventListener('click', addToCart);
    });

    loadCartItems();
});


function handleSearch(event) {
    event.preventDefault(); 
    let searchInput = document.querySelector('#search-box').value.trim().toLowerCase();

    let sections = {
        "home": "#home",
        "about us": "#about",
        "about-us": "#about",
        "aboutus": "#about",
        "menu": "#menu",
        "review": "#review",
        "reviews": "#review",
        "gallery": "gallery.html",
        "contact": "contact us/index.html",
        "services": "#services" 
    }

    if (sections[searchInput]) {
        window.location.href = sections[searchInput]; 
    } else {
        alert("Not found!"); 
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('#search-form').addEventListener('submit', handleSearch);
});

document.querySelector('#cart-btn').onclick = () => {
    cartItemContainer.classList.toggle('active'); 
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    updateCartUI(); 
};



