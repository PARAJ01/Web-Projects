let navbar = document.querySelector('.navbar');
let cartItemContainer = document.querySelector('.cart-items-container'); // Cart container
let cartItemsDiv = document.querySelector('#cart-items'); // The div where cart items are displayed
let cartItems = []; // Array to store cart items


document.querySelector('#cart-btn').onclick = () => {
    cartItemContainer.classList.toggle('active'); // Ensure cart opens
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    updateCartUI(); // Update cart when opened
};

document.addEventListener('DOMContentLoaded', () => {
    let navbar = document.querySelector('.navbar');
    let searchForm = document.querySelector('.search-form');
    let cartItemContainer = document.querySelector('.cart-items-container');

    window.onscroll = () => {
        if (navbar) navbar.classList.remove('active');
        if (searchForm) searchForm.classList.remove('active');
        if (cartItemContainer) cartItemContainer.classList.remove('active');
    };
});


// Function to add item to cart
function addToCart(event) {
    let button = event.target;
    let item = button.closest('.box'); // Find the closest item box
    let itemName = item.querySelector('h3').innerText;
    let itemPrice = item.querySelector('.price').childNodes[0].nodeValue.trim();
    let itemImage = item.querySelector('img').src;

    // Check if item already exists in the cart
    let existingItem = cartItems.find(cartItem => cartItem.name === itemName);
    if (!existingItem) {
        let cartItem = {
            name: itemName,
            price: itemPrice,
            image: itemImage
        };
        cartItems.push(cartItem);
        
        // Save cart items to local storage
        localStorage.setItem("cartItems", JSON.stringify(cartItems));

        updateCartUI(); // Update cart display

        // Ensure cart is visible after adding an item
        cartItemContainer.classList.add('active');
    } else {
        alert('Item is already in the cart');
    }
}

// Function to update cart UI
function updateCartUI() {
    let cartContainer = document.querySelector('#cart-items');
    cartContainer.innerHTML = ''; // Clear previous cart items

    if (cartItems.length === 0) {
        cartContainer.innerHTML = `<p class="cart-empty" style="text-align:center; font-size:1.6rem;">Cart is empty</p>`;
        document.querySelector('#checkout-btn').style.display = 'none'; // Hide checkout button
    } else {
        document.querySelector('.cart-empty')?.remove(); // Remove "Cart is empty" message if items exist

        cartItems.forEach((item, index) => {
            let cartItemHTML = `
                <div class="cart-item">
                    <span class="fas fa-times" onclick="removeFromCart(${index})"></span>
                    <img src="${item.image}" alt="${item.name}">
                    <div class="content">
                        <h3>${item.name}</h3>
                        <div class="price">${item.price}</div>
                    </div>
                </div>
            `;
            cartContainer.innerHTML += cartItemHTML;
        });

        document.querySelector('#checkout-btn').style.display = 'block';
    }
}

// Function to remove item from cart
function removeFromCart(index) {
    cartItems.splice(index, 1); // Remove item from array

    // Update local storage
    localStorage.setItem("cartItems", JSON.stringify(cartItems));

    updateCartUI(); // Update UI
}

// Function to load cart items from local storage
function loadCartItems() {
    let storedCart = localStorage.getItem("cartItems");
    if (storedCart) {
        cartItems = JSON.parse(storedCart);
        updateCartUI(); // Ensure UI updates with saved cart items
    }
}

// Attach event listeners to "Add to Cart" buttons after DOM loads
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.menu .box .btn').forEach(button => {
        button.addEventListener('click', addToCart);
    });

    // Load stored cart items when page loads
    loadCartItems();
});


/// Function to handle search and redirect
function handleSearch(event) {
    event.preventDefault(); // Prevent form submission reload

    let searchInput = document.querySelector('#search-box').value.trim().toLowerCase();

    // Define available sections
    let sections = {
        "home": "#home",
        "about us": "#about",
        "about-us": "#about",
        "aboutus": "#about",
        "menu": "#menu",
        "review": "#review",
        "reviews": "#review",
        "gallery": "gallery.html",
        "contact": "contact us/index.html",
        "services": "#services" // Only if you have a "services" section
    };

    // Check if the search term matches any section
    if (sections[searchInput]) {
        window.location.href = sections[searchInput]; // Redirect to the section
    } else {
        alert("Not found!"); // Show popup if no match
    }
}

// Attach event listener to the search form
document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('#search-form').addEventListener('submit', handleSearch);
});

document.querySelector('#cart-btn').onclick = () => {
    cartItemContainer.classList.toggle('active'); // Ensure cart opens
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    updateCartUI(); // Update cart when opened
};



